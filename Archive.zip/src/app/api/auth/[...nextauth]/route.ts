import { handlers } from '@/app/api/auth/[...nextauth]/auth-options';

export const { GET, POST } = handlers;
